What is your interpretation of one of your recent dreams❓
What does death teach us about life❓
When you look at an elderly person's hands what do you see❓
Which disease known to humankind do you hate the most❓ Explain why.
What was your last dream about❓
What seemed unusual on your morning commute today❓
Tell me about an old friend you've lost touch with.
What's your earliest holiday memory❓
What's your favorite charitable cause and why❓
What do you think your life will be like ten years from now❓
What actor would you hire to play you in your TV movie biography, and why❓
If you died tomorrow, what would you most be remembered for❓
Name three people whose lives have been improved by knowing you, and explain why.
If your life was a reality TV show, what would be the hook that would draw viewers in❓
When was the last time you cried❓
What is the earliest memory you have of a sibling❓
What is the earliest photograph of yourself that you have that you remember when it was taken❓
What is the longest you've had a 'borrowed' item but not been able to return it because they moved❓
What did you eat as a child that you can't stand now as an adult❓
What is one thing that happened today that I really want to remember 10 years from now❓
Did I do something today that I can be proud of❓
What is one thing that I am grateful for today❓
Did something happen to make me sad❓
Who is the one relative that I miss the most❓
What would I say to them if I could see them again❓
Why is it important to be genuine❓
Why do you think wars exist in the world❓
Why would we say that someone is 'bananas'❓
Why do you think ability to focus is an important quality❓
Explain why we say, 'Dead as a door nail'.
How do you feel about using humans in medical research❓
What does 'copy cat' mean to you❓
What do you think about quasi ghosts❓
What does 'holds water” mean to you❓ What is your first memory❓
How did you meet your first boyfriend or girlfriend❓
Describe your typical day, from wake to sleep.
What would be your ideal birthday present, and why❓
If you could take home any animal from the zoo, which would it be, and what would you do with it❓
Think of a loved one that you have lost. If you could ask this person one question, what would you ask, and what do you think they would say❓
Where do you think you will be in five years❓
If you were to die today what would like people to say about you❓
What is your proudest accomplishment❓
If you could be anybody, who would you be❓
What is the most important aspect of your life and why❓
Where would you travel, if you could go anywhere❓
What time period you would like to be born in❓
What extinct animal would you bring back, if you could❓
What profession would you have chosen, if not your current one❓
What book setting would you like to visit, if you could❓
Given the chance to give your child only one quality as a person, which would you choose❓ How about if that choice were unavailable, what would be your second and maybe third choices❓ Why are these so important to you❓
Which superpower would you choose to have if you had the option and why❓ Conversely, which superhero do you find to be the most overrated and why❓
You have one week to do whatever you want, all-expenses-paid, what things would you want to do❓ Where would you go❓
If your best friend came to you depressed and upset like you've never seen before, how would you react❓
In what ways do you sometimes wish to act to be a better friend, but don't❓ Why do you find yourself unable to do these things❓
You have one hour to come up with the most interesting television show you can and describe∕pitch it.
'If someone gains, someone else loses.' How much does this reflect life, and how much does it come up short. Reflecting upon this, how could your attitudes have been different during events in your past❓
Would you be a different person today if you had a different childhood❓ How❓
Consider some of the parents others had growing up. What type of person would you be if you had those situations❓
What if your life had been harder or easier❓ How do you think you'd be different❓
Am I happy with my job, life, and situation❓ What parts are good❓ What parts are bad❓
If I could change one thing about my spouse∕lover, what would I change❓
What is the greatest vacation I have taken and what lessons can I take from it❓
If you won a million dollars but had to give it all away, who would you give it to and why❓
What was your first pet❓ Why did you choose this pet❓
If you could build a car customized just for you, what would it contain❓
What did you want to be when you grew up❓
If you had to write your life story, what would the title be❓ Why❓
How do you feel when you see something beautiful❓ Have you ever seen something so beautiful it makes you cry❓
What are you thankful for❓
This morning, when I got out of bed, I ….. Before bed tonight, I will….
What do you think about as you are falling asleep❓
What is the most beautiful thing you have ever seen❓
What is your favorite thing to do outdoors❓ Why❓
What would you write in a letter you could send back in time to yourself as a teen-ager❓
What would you write in a letter you could send forward in time to yourself in 10 years❓
When did you first realize you would someday be old or someday die❓
Describe what it was like to fall in love.
Explain how you chose your career path.
When have you realized you were really wrong in your judgment about someone❓
How do you react when you realize you've made a mistake❓
What situation has caused you to confront your ethics recently❓
If you had to sacrifice one of your senses (taste, touch, smell, sight, hearing), which would you choose and why❓
What about a goal makes you most likely to procrastinate❓
What would it be like to be in a tornado❓
Where would you go to relax and why❓
How do you make ice cream❓
Why does the ocean have a tide❓
Who has more power the government or the people❓
Did I recently have an interesting conversation❓
What is a scary dream that I remember from my past❓
Who is the person that I feel has altered the course of my morals and values, and how did they effect me❓
Where do I see myself, so far as my goals, personal development, residence, or job, in five years, and do I have a plan to arrive at this destination❓
What is my earliest or happiest memory❓
Which amendment to the constitution is the most important to you and why❓
Is speech always free❓ When and where might it not be free❓
Put yourself in Anne Frank's place how would you have survived❓
If you witnessed a fight at school would you report it❓ What could the repercussions be if you told the truth❓
What was(will be) the first thing that you did(do) when you got your driver's license❓
What would you do if you woke up one morning with a tail❓
How would you react if you were to find out you would be the first child in space❓
Who would you most like to be like if you could change your personality❓
If you were born in another time, what time would you choose and why❓
Where would you most like to watch the sun come up❓ Why❓
How do you think instant riches would affect your friendships and familial relationships❓
How do you think sudden loss of millions would affect your familial relationships and friendships❓
How do you imagine humans would move to Mars in the event of world wide catastrophe❓
If you were elected President, what do you think would be your most difficult tasks❓
Describe something you feel most passionate about to a complete stranger.
Describe your favorite memory about an amusement park or county fair you visited.
When was the last time you lied and why.
What was your closest brush with death.
Where would you want to live if Earth was uninhabitable.
Remember the last time you spoke to a person who later died.
If you were to die tomorrow, what would you want your last words to be❓
Write about the last time weather scared you.
Who was the best teacher you ever had, and why❓
Describe your favorite sound.
When were you the happiest this year❓
What would you do on a snow day❓
What are you saving up for❓
What caused me to wince today❓
Who did I run in to today that I would like to spend more time with❓
What tempted me today❓
What yes or no questions should I decide by flipping a coin❓
What trait did you admire in a relative, friend, classmate, or coworker today❓
How do you feel when you stare at the stars❓
What would you say to your loved ones if you could tell them absolutely anything❓
If you could tell your boss what you really want to do in your job, what would it be❓
How are you going to make tomorrow a joyful day❓
Recall a place, person or event, what emotion do you remember feeling most strongly❓
If you could return in time to a set time to relive it, but not change anything, what would you choose and why❓
What is your strongest memory, as a child, of your parents and what were you all doing at the time❓
You are given 24 hours to do whatever you would like, money no object. What do you do and why❓
You have to invite 5 people to dinner, dead or alive. Who do you invite and why❓
What makes your favorite song so special❓ How do you personally relate to it❓
What are some colors you see the most in your every day life❓
What is your fondest memory of an animal or pet you once had❓
If you could go back and relive one of your past trips, whom from your current entourage would you take with you❓
What happens in the latest movie you saw❓
Can you picture yourself in the shoes of any of the protagonists❓
What is the best gift you've ever given someone❓ Why❓ Why do you like∕dislike the city where you live❓
What's your most treasured memory from high school❓
Which friend has had the greatest impact on your life and why❓
Which photo of yourself do you hate the most, and why❓
Who inspires you the most, and why❓
Can you buy happiness❓
Imagine you're stuck on the roof of a house that has been carried away by a flood. Which person would you most like to be on the roof with you❓
Which would you choose: immense wealth in obscurity or poverty and fame (think 'starving artist')❓
What animal do you identify with most closely❓
What is your favorite season and why❓
Imagine you are attending your dream concert—what songs would you want to be played❓ What does the stage look like❓
What's your favorite place to escape from life temporarily❓ A park❓ A mall❓
What's one job you would never want to do❓
Has a friend ever broken something or yours❓ How did you react❓
What's the best memory you have from the last year❓
How do you feel about politicians openly sharing their religious beliefs❓
What characteristics or personality traits are most important to you in a politician❓
If you could trade places with a famous person for a day, who would you like to be and why❓
If you could learn any new language, which one would you choose and why❓
If you had to choose between having a personal chef, a housekeeper, or a personal trainer, which would you pick and why❓
What is the weather like today❓ How do you feel about it❓
What season do you like best❓
What do you wish you could tell someone, and who do you wish you could tell❓
When you close your eyes and think of where you want to live, what comes to the surface❓ Specifically, what do you want your space to look like❓ And what do you think that reflects about you❓
If you don't believe in reincarnation, forget about that for a minute. What would you like to be reincarnated as❓ What do you think you WOULD be reincarnated as, if karma had its way with you❓
What are things that you wish people knew about you without your having to tell them❓
What are a few qualities you dislike in other people, and why❓
What music makes you want to get up and dance❓ Why don't you❓
If you need inspiration and put on your favorite CD, which one is it❓ What is your favorite song on this CD❓ Why do these lyrics 'speak' to you❓ If you met the artist, what would you ask him❓ If you could be in the front row, where would you see him∕her in concert❓
If you were in the band, what instrument would you be playing❓
When do you think about your regrets the most often❓
What is your most prized possession❓
What is your favorite lie to tell❓
Who do you live for❓
What is a secret about you❓
What family item has changed your view or ideas about a family member❓
Write about your best friend as if they were a stranger.
If you could build a soundtrack to your life, who would be on it❓
If you suddenly gained the ability to tell whether someone was lying, would you use it❓
How would handle life in an arctic climate❓
Describe your perfect career or job. Where would it be❓ Would you want financial or personal fulfillment❓ What kind of people would you work with❓
Who is your ideal presidential candidate❓
What kind of jobs have you had in the past❓
What was your major in college❓ How did you choose it❓
Where are you from❓
How would you go about 'saving the world'❓ What do those words mean to you❓ How long would it take❓ Where would you start❓
If you were to write a book, would it be fiction or non-fiction❓ What would the subject be❓ Who is your target audience❓
What's the first step you can take to making a difference in the world today❓ Would you try to feed the hungry, improve the environment, promote peace❓ How would you start❓
In your opinion, is Global Warming real❓ If so what is causing it❓ If not why is everyone so hyped up about it❓
Write a story about what 1 day in your life would be like if you were a dog.
Describe the ocean to a person who is blind.
Using all of your 5 senses, describe your favorite food.
How would you spend your time if you were wealthy❓
Look at yourself in the mirror and describe what you see.
Pretend you are a raindrop falling to earth and describe your fall from the clouds.
What is one of your most personal hopes and dreams❓
Would you rather be rich and famous or just rich❓ Why❓
What is your favorite season❓ What is your best memory of something that happened in that season❓
What’s one place that you would like to visit but never will❓ Why will you never go there❓
Describe your favorite painting and what you think the artist was trying to create.
Describe what you hear when you hear nothing.
What's the most difficult part about being you❓
What's your favorite part of being you❓
If you had to move across the country what belongings would you get rid of❓
What was your favorite thing to collect as a child, and why❓
What if you ran into a talking animal, what would you ask it❓ How would you react❓
If you saw an alien, what would you do❓
What would you do if you won the lottery❓
What would you do if you found an injured animal in the street❓
What animals frighten you and why❓
Where is your favorite place to be and why❓
What is your favorite book and what do you like most about it❓
What is the best thing and the worst thing that happened to you this week❓
If you could travel anywhere in the world for a vacation, where would it be and why❓
When you were a child, how did you imagine your adult life❓ How is it similar or different to what you imagined❓
If you found a suitcase full of money in the middle of the street, what would you do❓
What is one skill you wish you had and how would that make your life different❓
What is the best gift you have ever received from someone and why❓
If you were the ruler of the planet, how would you handle space exploration❓
If you had a mind-reading ability but could only choose 3 people to read their minds, who would they be❓
If there was one person who you had the power of giving immortality to, who would it be and why❓
If you found treasure worth millions in your backyard, would you keep it a secret or would you tell the world❓
Why do some people choose to dress differently❓
What if you lived your life in reverse (being born old, etc.)❓
What if trash became more valuable than money❓
How would you be different if you had never watched television❓
Imagine trading places with the first person you spoke to today.
What do you dream about on a regular basis❓
Where do you see yourself in five years❓
What would you like to accomplish by the end of the year❓
How do others see you❓
What would you do if you had all the money in the world❓
What would you do to change the country and the world for the better if you were elected president❓
Why do you journal❓
What do you regret and why❓
Make a list of what you would like to do before you die.
Complete this sentence: Love is…
What is the best way to educate the world on lead and how it affects people, just one person at a time❓
If I could run out to any restaurant right now with more than enough money where would I go❓
Could writing a children's book really affect a child for the rest of their life❓
Just a spoonful of what makes the medicine go down❓
If you could be a color what would it be❓ Why❓
Tell about a time when someone made you feel welcomed or accepted. What did they do and how did it make you feel❓
Tell about a time when someone made you feel bad about yourself. What did they do and how did you react❓
Think about the phrase 'random acts of kindness'. What are five things you could do for someone this week just to be kind❓
What one thing could you invent that would make your life easier❓
What are you most grateful for❓
Describe your most important possession.
Why is your best friend your best friend❓
What is the biggest goal for your life
What is your most embarrassing moment and why❓
Who do you trust the most and why❓
Who do you trust the least and why❓
What is your greatest fear and how often do you think about it❓
What gives you confidence and why❓
What is your least favorite chore and why❓
What medium would your life best be shown as❓ A movie❓ A television series❓ A cartoon❓ What genre would a movie about your life fall under❓ Comedy❓ Romance❓
Who would you choose to portray you in a movie about your life❓
What would you do if you could stop time❓
What kind of fairytale creature would you be❓
What would you do if you could hide in your mother's womb❓
What would you do if you knew the answer to pollution of the earth❓
What would you do if you met yourself without knowing it was you❓
What would you do if you were Mick Jagger for 1 day❓
What would you do if you were homeless❓
What would you do if you were an undercover agent in heaven❓
What would you do if you were living in an environment where nobody could speak❓
What would you do if you would stay 25 forever❓
What is a long term goal and how can you achieve it❓
Who is someone that inspired you to accomplish something you didn't think you could do and how did they encourage you❓
Where is your favorite vacation place and why❓
If you could travel anywhere in the world, where would you go and what would you do❓
What is your ideal pet❓
What is a convenience you wouldn't want to do without❓
Tell about your favorite vacation experience.
Tell about your worst vacation.
Tell about a story when you got a parking ticket or traffic violation.
What was the first way you earned money❓
What is an unusual form of transportation you have used❓
Have you ever had an incident because you overslept❓
What is an experience you have had when you went fishing or swimming❓
Tell about the best restaurant you have ever been to.
What is your favorite game❓ Why❓
Have you ever been in a car wreck❓ How many❓ Whose fault was it❓
Have you ever swallowed something strange❓ (a key, pin, marble…)
Do you belong∕have you belonged to a club or an organization❓
What is a famous place you have seen or want to see❓
Do any of your friends or relatives have strange occupations❓
Describe an incident that had something to do with water.
Have you ever moved❓ Tell about one of your moves.
Tell about an article or book you read recently.
What is a joke you played on someone❓
Describe a babysitting experience you have had.
Are you competitive❓ Tell about a competition that you participated in.
Describe something unusual that happened while you were eating in a restaurant.
What is something strange that happened in your neighborhood❓
Describe a fair, parade, or festival you have attended.
Describe an incident at a beauty or barber shop.
Tell about a time you slept outdoors.
Do you have pets❓ Tell a story about one of them.
Tell about a dream that you can remember.
Do you believe in God❓ Why or why not❓
Tell about a time you were given, or gave, flowers.
Tell about a cultural clash∕experience you have had with a culture other than your own.
Have you, or your family, ever been effected by war❓ Describe how.
What is an incident you have had at a movie theater❓
Where did you grow up❓ Describe what it was like❓
What is an exciting or crazy trip you have taken❓
At what age did you learn to ride a bicycle❓
Is there a movie that has brought you to tears❓ Tell about it.
Tell about a neighbor you had a hard time living next to.
What is the strangest wedding you have ever attended❓
What is the worst weather condition you have ever experienced❓
What is the best party you have ever been to❓
Recall an unusual bus, train, or plane ride.
What is a New Year's Eve you will never forget❓
If money wasn't an issue, what kind of house would you have❓
Tell about living or visiting a farm or ranch.
If money wasn't an issue, what car(s) would you have❓
What foreign countries have you been to❓ Which ones do you want to go to❓
Tell about a trend when you were born.
Have you had an experience that made you feel close to nature❓
Which decade of clothing fashion was your favorite and least favorite❓
How much was Gas the last time you filled up❓
What do you like to do when it is really hot outside❓
What is your all-time favorite sports team❓
Who is your all-time favorite sports player❓
Name someone or an event that guided you in choosing your vocation or work.
What was your first favorite TV show❓
Do you actively change your habits and behaviors to help the environment❓ What kinds of things do you do❓
What are some major inventions that happened during your life time❓
Tell what you like about one of your hobbies.
What musical instrument(s) do you play or wish you could play❓
Tell about a habit that you picked up from a family member or friend.
What about your work can you take pride in❓
Tell about the strangest food you have ever eaten.
Do you like commercials❓ Tell about your favorite commercial.
How are you like one of your brothers or sisters❓
Tell about a time when you met someone famous.
Describe a favorite letter you have received.
Describe the first time you ever danced with someone.
What is something that made your mother happy.
How are you and your parents alike.
What is your greatest athletic achievement❓
How did your parents meet❓
Tell a story that you have had with one of your aunts.
Tell a memory that you have with one of your grandmothers.
Tell a memory that you have with one of your grandfathers.
Name one of the kindest people you have ever met. Why❓
Tell about the first time you ever held hands with someone.
Who is one of the most courageous people you have ever met❓ Why❓
What is one of your favorites favorite sayings❓ Tell how they used it and when.
Describe your father's personality in a short journal entry.
Describe your mother's personality in a short journal entry.
Describe each member of your family one by one. Ad photos and personality descriptions.
What kinds of activities when on at the kitchen table at home when you grew up (eating doesn't count)❓
Tell about the kind of kids you hung out with as a kid.
What is your favorite sport❓ Why❓
What is a smell that you remember from growing up❓
Tell one of your favorite childhood stories.
What is one unanswered question you would like to ask your parents❓ Why❓
Describe a family vacation.
Tell about one of your father-daughter∕son activities.
Describe your best childhood friend.
Tell about one of your mother-daughter∕son activities.
Describe your first date.
Who in your family is the biggest character❓
Tell a memory you have with one of your uncles.
What is one unanswered question you would like to ask your grandparents❓ Why❓
Tell about a time you got in trouble at school.
What is your favorite family dinner❓
What was your favorite family dinner as a child❓
Tell about a time when you were grounded.
Who is one of the most interesting people you have ever met❓
What state or country what was your father raised in❓
What state or country what was your mother raised in❓
What state or country what is your father's family from❓
What state or country what is your mother's family from❓
Where was a special place you always retreated to as a child❓
Where is a special place you go to so you can be alone❓
Who is a person that influenced your life❓ How❓
How did your family fight the common cold❓ What was the 'cure'❓
Did you grow up with lots of money or very little❓ How much money (give numbers it makes things interesting)❓
Has anyone ever influenced your manners for the better❓ Who❓
What did your family do on Sundays as a child❓
Describe your first boyfriend or girlfriend.
Tell about your first kiss.
What is a game or song that your family played or sang while driving❓
What did your parents do for fun❓
Who was one of your best, or worst, teachers❓ Describe them.
Tell about something that you and your siblings used to do together.
Tell about something that you and your siblings do together now.
Tell something you like about a friend from the past.
Who is your favorite relative❓ Least favorite❓
Who is a friend you haven't seen for a long time but would like to see.
What was∕is something that your mother considered∕considers very important❓
What was∕is something that your father considered∕considers very important❓
What is something you liked about your childhood❓
What kinds of things make∕made your father happy❓
What is an event that you will never forget from your school days❓
Tell about one of your first away-from-home experiences.
Tell about one of the oldest photographs you have.
How are your father and grandfather alike❓
How are your mother and grandmother alike❓
What are you political views❓ Are you a liberal❓ republican❓ libertarian❓ … Why❓
In your mind, what will the world be like in 50 years❓
If you were given a huge amount of money, but had to give it away, who would you give it to❓
Tell about the happiest day of your life.
Do you have a favorite time of day❓ Why❓
What is your favorite movie of all time❓
What is your favorite place to eat❓
What is your favorite holiday❓ Why❓
What would be your perfect day❓
If you had more money, what would you alter about your life❓
If TV didn't exist, what would you do with your time❓
If you could change you name, what would you change it to❓
Cost being no factor, what would you do for one month❓
Who is your #1 hero❓ Why❓
If you could live anywhere in the world, where would it be❓
How are you going to celebrate entering the next century❓
As a whole, do you live for tomorrow or today❓ Explain.
If you had the option of living forever, would you take it❓
If you had the option to know the day and time of your death, would you want to know❓
What is a place that inspires you❓
What age would you consider the prime of life❓ Why❓
Describe a family tradition.
How have credit card affected your life❓
What do you really like about where you live❓
Are you ever lucky❓ Tell about it.
If you knew you would loose ever possession you own but one, what would you keep❓
What is your perfect weekend❓
Describe the perfect vacation.
Tell about how your parents influenced your spiritual beliefs.
How is your life different now from just a year ago❓
What is your favorite season❓ Why❓
What is your favorite holiday❓ Why❓
Name a public figure who has inspired you. Why❓
How have you adjusted your eating habits to be healthier❓
Describe when someone has done something very nice for you.
If you could spend a day with someone famous, who would it be❓
Tell about a time you laughed until you cried.
What is a cause that is VERY important to you❓
Do you exercise❓ How has your exercising changed throughout your life❓
What do you do to relax❓
What have you done that was 'out of character.'
Tell about a time when you shocked someone.
What is the biggest risk you have ever taken❓
What occupation do you think would be fascinating❓
What is a principle or ideal that you would like to pass on to the next generation❓
Tell about an award you have received.
Tell about a friend you have with a different national background.
What is the proudest moment of your life❓
What do you feel is your greatest success❓
What is the best decision you have ever made in your life❓
What kind of art is your favorite❓ Why❓
What is an experience that you would consider a miracle❓
Tell about a characteristic in others you admire❓
What is the most courageous thing you have ever done❓
What is one of your life goals❓
Write out your life mission statement (or at least start)
What was your New Years Resolution this year❓
What would you put in a time capsule to be opened by the next generation❓
Has religion played a role in your life❓ How❓
Describe a time you helped someone.
What is something about yourself that you dislike❓
Tell about something you do well❓
Tell about your home. Do you have a favorite room❓ Why❓
What makes a good neighbor❓
What do you think the world will be like in 10 years❓ Twenty❓ Fifty❓
What is your opinion about ghosts❓
What is your opinion of someone who has bad manners❓
What is your opinion about people who take advantage of others❓
What do you think about when you can't fall asleep❓
What do you think courage means❓
What do you think makes a good friend❓
What do you think makes a happy family❓
What things do you think are beautiful❓
What is your opinion of 3D movies❓
What is your opinion about the amount of violence on T.V.❓
What is your opinion of people polluting the environment❓
What is your opinion of having set rules for people to follow❓
What is your opinion of people who are inconsiderate of others❓
How would you feel if you were going to be on TV❓ Why❓
What is the best way to treat busybodies❓
What is the worst thing parents can do to their children❓
What is your most invaluable possession and why❓
Where do you see yourself in 5 years❓
What is your idea of perfect happiness❓
What is your greatest fear❓
What historical figure do you most identify with❓
What living person do you most admire❓
What trait do you most deplore in yourself❓
What is your greatest extravagance❓
What is your favorite journey❓
What do you consider your most overrated virtue❓
What do you dislike most about your appearance❓
Which living person do you most despise❓
What words do you most overuse❓
What or who is the greatest love of your life❓
Which talent would you most like to have❓
What is your current state of mind❓
What do you consider your greatest achievement❓
If you could choose what to come back as, what would it be❓
If you were to die and come back as a person or thing, what do you think it would be❓
If you could change one thing about your family, what would it be❓
What is your most treasured possession❓
What is your favorite occupation❓
What is your most marked characteristic❓
What is the quality you like most in a woman❓
What is the quality you like most in a man❓
Who are your favorite writers❓
What do you most value in your friends❓
Who is your favorite hero of fiction❓
What is it that you most dislike❓
How loyal are you❓
How would you like to die❓
What’s the finest education❓
What’s your motto❓ How would you like to be remembered❓
What is your idea of a boring evening❓
What is something you are optimistic about❓
What is something you are pessimistic about❓
What is your favorite song and why❓
What is the best birthday present you ever received❓
What is the best birthday present you could receive❓
What is something that makes you feel sad❓
What is your favorite book and why❓
What is something that really bugs you❓
What is something that really makes you angry❓
What is the best advice you ever received❓
What is your favorite holiday❓ What makes this holiday special❓
What is your favorite day of the week❓
What is your favorite month❓ Why❓
What would happen if there were no television❓ Why would this be good❓ bad❓
What would you do if you saw a friend cheating—report it, confront the friend, nothing—and why❓
If you could have been someone in history, who would you have been❓
If you could only take 3 people with you on a trip around the world, who would you take and why❓
If you could give any gift in the world, what would you give and to whom❓
If you could live anywhere in the world, where would it be❓
If you received any sum of money as a gift, what would you do with it❓
If you could do whatever you wanted to right now, what would you do❓
If you were principal of this school, what would you do❓
If you were a mouse in your house in the evening, what would you see your family doing❓
What rituals do you have or hold❓
If you were lost in the woods and it got dark, what would you do❓
If it were your job to decide what shows can be on t.v., how would you choose❓
If there were no rules, what do you think would happen❓
What do you think people say to each other when you're not around❓
If you owned a store, what would you do to discourage people from stealing from you❓
If you could participate in an Olympic event, which one would you choose and why❓
If you could break the Guiness Book of Records it would be for❓
If you had to describe yourself as a color, which would you choose❓
What do you think should be done to keep people who are under the influence of alcohol off the road❓
What do you like most about yourself❓
What do you like to do in your free time❓
What kind of animal would you like to be and why❓
What kind of trophy would you like to win❓
What TV or movie star would you like to invite to your birthday party❓
What does 'Clothes make the person' mean to you❓
What does 'Have your cake and eat it too' mean to you❓
What does 'The early bird gets the worm' mean to you❓
What do we mean when we say, 'The grass is always greener on the other side of the fence'❓
What does 'You can't take it with you' mean❓
What do we mean when we say, 'You can catch more flies with honey than with vinegar'❓
What do we mean when we say, 'Hitch your wagon to a star'❓
What does 'still waters run deep' mean to you❓
What does 'There are two sides to every coin' mean to you❓
What does Canada mean to you❓
What are you afraid of❓ Why❓
What are junk foods❓
What are some nutritious foods that you like❓
What are some rules you have to follow at home❓
What are some examples of prejudice❓
What is more important to you, appearance or personality❓
What is most important to you in a friend—loyalty, generosity, honesty—why❓
What is something that makes you melancholy❓
What makes your best friend your best friend❓
What makes you feel safe❓
What makes you laugh❓
What would you invent to make life better❓
What would you do to entertain your family without spending any money❓
What effects does watching violence have on people❓
What effects do cigarette and alcohol advertising have on young people❓
What kind of t.v. commercial would you like to make❓ Describe it.
What kind of pet would you most like to have—monkey, snake, goat—why❓
What kind of program do you enjoy most on TV—detective shows, comedies, game shows—and why❓
What advice would you give a new student❓
What advice would you give to someone who stole something but now feels guilty❓
What things are better than going to school❓ Why❓
What talents do you have❓
What three words would describe you right now❓
What four things are most important in your life❓
What color makes you think of happiness❓
What has been the most fun activity at school so far❓
What quality do you like about yourself—creativity, personality, appearance—why❓
What eccentric behaviour in a friend disturbs you the most❓
What parts of nature do you like best❓
What do you do for exercise❓
How do you feel when it's your birthday❓ Why❓
How do you feel on the first day of winter❓ Why❓
How do you feel when you do something wrong❓
How do you feel when you do something that is very good❓
How do you feel when you play a trick on someone❓
How would you feel if a new child moved into your neighbourhood❓
How do you think the new child would feel❓
How do you feel when you have had a fight with your best friend❓
How do you think your friend felt❓
How do you feel when you are in bed with the lights out❓
How do you feel when you want something very badly and you cannot have it❓ Why is this so important to have❓
How do you feel on a warm sunny day❓
How do you feel when you stay with a babysitter❓
How do you feel when you're leaving home on vacation❓
How do you feel when you sleep at some one's house❓
How do you feel during a thunderstorm❓
How do you feel on the first day of school❓
How do you feel when your parents are upset with you❓ Why do they become upset with you❓
How do you feel on Thanksgiving❓ What are you thankful for❓
How do feel on (any holiday)❓
How do you feel when something scares you❓ What do you do when this happens❓
How would you feel if someone told you that you were his or her best friend❓
How do you feel about your appearance❓
How would you change the world to make it better❓
How do you think eating junk food affects you❓
How do you have the most fun—alone, with a large group, with a few friends—and why❓
Explain how to play your favorite game.
I wish I had a million… Then I would…
I wish I had one… because
I wish I could be like…. This person is special because….
I wish to be a ………… when I grow up. Then I will….
I wish there were a law that said….. This would be a good law because….
I wish I could forget the time I ….. because….
I wish trees could….. because….
I wish I could see…… because…..
I wish I could learn….. because…..
I wish I didn't have to eat…… I don't like this food because…..
I wish everyone would learn to ….. Then everyone would…..
I wish I never……
I wish I had one more chance to….. Then I would…..
I wish there was an electric……
I wish I had enough money to……
I wish everyone loved……
I wish all children would……
I wish everyone had…..
I wish I could touch……
I wish animals could…… If they could, then…..
I wish I looked like…. because……
I wish there were no more…..
I wish I didn't have to…..
I wish I could go to…..
I wish there really was….. If there really was, then…..
I wish I could hear……
I wish I could give……
If all my wishes came true, I would……
Describe a time when you felt vengeful.
Describe your favorite toy. Why do you like it best❓
Describe the most ludicrous outfit you can think of.
Describe the best teacher you ever had.
When you are angry, how do you look❓
When are you happiest❓
When have you felt lonely❓
When do you feel proud❓
When was the last time you cried and why❓
When a friend was in an embarrassing situation, what did you do❓
When it might hurt their feelings, how do you feel about telling your friends the truth❓
When might it be bad to be honest❓
When someone picks on someone else, how do you feel❓ What do you do❓
Once, when you were very frightened, what happened❓
Once, when you were embarrassed, what happened❓
Once, when your feelings were hurt, what happened❓
Which quality best describes your life—exciting, organised, dull—and why❓
Which quality do you dislike most about yourself—laziness, selfishness, childishness—and why❓
Which place would you most like to visit—Africa, China, Alaska—why❓
Which holiday has the most meaning for you-Canada Day, Thanksgiving, Valentines Day—and why❓
Which is least important to you—money, power, fame—and why❓
Which is most important to you—being popular, accomplishing things, being organised—and why❓
Who do you talk to when you have a problem❓
Who is your favourite Star Wars character (or other movie∕book∕t.v. show, etc.)❓
Who or what has had a strong influence in your life❓
Where would you prefer to be right now—mountains, desert, beach—and why❓
Why is it important to be honest❓
Why is important to have good manners❓
Why do you think some people smoke∕drink❓
Why is exercise important to someone your age❓
Why do you think some people encourage others to smoke∕drink❓
Why do you think the rules you must follow are good or bad❓
Why would it be good to be honest❓
Why have men and women usually only done certain types of work❓
Why should or shouldn't a man stay home to care for the house and children while his wife goes to work❓
Why do you think some people take advantage of others❓
Why do you think prejudice exists in the world❓
Why would we say that someone is 'passing the buck'❓
Why would a Prime Minister have a sign on his desk which read, 'The buck stops here'❓
Why do you think tact is an important quality❓
Why is it not wise to squander your money❓
Explain why we say, 'dead as a door nail'.
Do you think there is too much fighting on t.v. Why or why not❓
Do you think it is necessary to have alcohol at a party in order to have a good time❓
Does it bother you to be around someone who has bad manners❓
Should there be a dress code in places such as school, restaurants, and places of business❓ Why or why not❓
Should animals be used for medical research❓
Should people be prohibited from smoking in certain places❓
Families are important because…
Would you like to be famous❓ Why or why not❓ What would you like to be famous for❓
If you were a food, what would you be❓
Why do people drive on parkways and park on driveways❓
What do you think is the greatest invention❓ Why❓
Describe what it means to be a best friend.
What is your earliest childhood memory❓
Is there something that you memorized long ago and still remember❓
Which way does the toilet paper roll go❓ Over or under❓
What is your favorite season of the year❓ Why❓
How many people are in your whole family❓ How many are male❓ Female❓
Who controls the TV remote control in your family❓
Name your favorite animated movie and tell why you like it.
Which person would you like to see more often than you do now❓
If you were an animal, what would you be❓
What superpower would you like to have❓ What would you do with it❓
If you had to move to another state, which one would you choose❓
What special talent do you have❓
What can you do that makes people laugh❓
Can you pat your head and rub your stomach at the same time❓
Name four items that can always be found in your refrigerator.
Who is the best laundry folder in the family❓
If somebody makes a mess, who cleans it up❓
When was the last time you sent or received a card from someone❓
Which do you prefer, a shower or a bath❓ Why❓
If you were in danger, who would protect you❓
What is your grandfather or grandmother's middle name❓
Which do you prefer, inside or outside❓ Why❓
What is something you dislike about yourself❓
What is something you do well❓
What is your favourite room in your home and why❓
What is a good neighbour❓
What is the worst thing parents can do to their children❓
What is your favourite time of day❓
What is your idea of a dull evening❓
What is the best way to treat meddlesome people❓
What is something you are optimistic about❓
What is something you are pessimistic about❓
What is your most indispensable possession and why❓
What is the meaning of 'He laughs best who laughs last'❓
What is your favourite song and why❓
What is the best birthday present you ever received❓
What is the best birthday present you could receive❓
What is something that makes you feel sad❓
What is your favourite book and why❓
What is something that really bugs you❓
What is something that really makes you angry❓
What is the best advice you ever received❓
What is your favourite holiday❓ What makes this holiday special❓
What is your favourite day of the week❓
What is your favourite month❓ Why❓
What would happen if you could fly whenever you wanted❓ When would you use this ability❓
What would happen if there were no television❓ Why would this be good❓ bad❓
What would happen if everyone lived in space❓ What type of houses would they live in❓ What type of clothing would they wear❓ What type of food would they eat❓ How would they travel❓
What if cows gave root beer instead of milk❓
What if all the streets were rivers❓ What would be different❓
What would happen if people never co-operated❓ Why do you think it is important to co-operate❓
What would happen if it really did rain cats and dogs❓
What would happen if animals could talk❓ What are some of the questions you would like to ask animals❓
What would happen if you could become invisible whenever you wanted to❓ What are some of the things you could do that you cannot do now❓
What would happen if everyone wore the same clothes❓
What would happen if you threw a piece of trash on the ground❓ What if everyone did❓
What if you could walk up walls and across ceilings❓
What would happen if you loved your neighbour as yourself❓ What if everyone did❓
What would happen if you grew taller than trees❓ How would this change your life❓
What would happen if children ruled the world❓
What would happen if there were no cars, buses, trains, boats, or planes❓ How would this change your life❓
What if everyone lived under water❓ Where would people live❓ What games would children play❓ What would school be like❓
What would happen if you found gold in your backyard❓
What would you do if a bully bothered you on your way home❓
What would you do if you did very poorly of a test❓
What would you do if a friend borrows things from you but never returns them❓
What would you do if You were the teacher and everyone forgot his homework❓
What would you do if you were in the middle of the lake and your boat began to leak❓
What would you do if Your friend had a broken leg❓ How would you cheer him up❓
What would you do if you saw little bugs in your salad❓
What would you do if you woke up in another country and no one could understand you❓
What would you do if you ordered an ice cream cone and you forgot to bring money❓
What would you do if someone got in front of you when you were in line at the movies❓
What would you do if your jelly sandwich fell upside down on the floor❓
What would you do if only one hot dog is left and neither you nor your friend have had one❓
What would you do if two of your best friends went to the movies without inviting you❓
What would you do if the surprise party was for you but you weren't surprised❓
What would you do if you got a present you didn't like❓
What would you do if you were at home and your homework was at school❓
What would you do if you dropped the cookie jar and it broke❓
What would you do if you were invited to two parties on the same day❓
What would you do if you promised to feed your pet and you didn't❓
What would you do if someone said you did something wrong and you didn't❓
What would you do if your new shoes felt fine in the store but now they are hurting❓
What would you do if someone told you a joke that you don't think is funny❓
What would you do if an hour before the party you remember you don't have a gift❓
What would you do if a friend comes to your house and his∕her mom doesn't know he's∕she's there❓
What would you do if you had four math problems marked wrong that were right❓
What would you do if you found in the street❓
What would you do if you found a magic wand❓
What would you do if you wanted to be friends with someone who spoke no English❓
What would you say if someone told you it was all right to steal from a large department store❓
What would you do if you saw a friend cheating--report it, confront the friend, nothing--and why❓
If you could have been someone in history, who would you have been❓
If you could only take 3 people with you on a trip around the world, who would you take and why❓
If you could give any gift in the world, what would you give and to whom❓
If you could live anywhere in the world, where would it be❓
If you received any sum of money as a gift, what would you do with it❓
If you could do whatever you wanted to right now, what would you do❓
If you were principal of this school, what would you do❓
If you were a mouse in your house in the evening, what would you see your family doing❓
If you were five years older you would...
If you were lost in the woods and it got dark, what would you do❓
If it were your job to decide what shows can be on t.v., how would you choose❓
If there were no rules, what do you think would happen❓
If you owned a store, what would you do to discourage people from stealing from you❓
If you could participate in an Olympic event, which one would you choose and why❓
If you could break the Guiness Book of Records it would be for❓
If you had to describe yourself as a colour, which would you choose❓
If your friend told you of a secret plan to run away from home, what would you do and why❓
What do you think of 3D movies❓
What do you think someone your age can do to help reduce the amount of pollution in our environment❓
What do you think the world needs now❓
What do you think your friends say to each other when you're not around❓
What do you think about the amount of violence on T.V.❓
What do you think about people polluting the environment❓
What do you think about having set rules for people to follow❓
What do you think about people who are inconsiderate of others❓
What do you think should be done to keep people who are under the influence of alcohol off the road❓
What do you think the world will be like when you are a grown up❓
What do you think about ghosts❓
What do you think of someone who has bad manners❓
What do you think about people who take advantage of others❓
What do you think about when you can't fall asleep❓
What do you think courage means❓
What do you think makes a good friend❓
What do you think makes a happy family❓
What pollutants do you think do the most damage and why❓
What things do you think are beautiful❓
What do you think about students having to wear school uniforms❓
What do you like most about yourself❓
What do you like to do in your free time❓
What kind of animal would you like to be and why❓
What kind of trophy would you like to win❓
What TV or movie star would you like to invite to your birthday party❓
What does 'Clothes make the person' mean to you❓
What does 'Have your cake and eat it too' mean to you❓
What does 'The early bird gets the worm' mean to you❓
What do we mean when we say, 'The grass is always greener on the other side of the fence'❓
What does 'You can't take it with you' mean❓
What do we mean when we say, 'You can catch more flies with honey than with vinegar'❓
What do we mean when we say, 'Hitch your wagon to a star'❓
What does 'still waters run deep' mean to you❓
What does 'There are two sides to every coin' mean to you❓
What does Canada mean to you❓
What are you afraid of❓ Why❓
What are junk foods❓
What are some nutritious foods that you like❓
What are some rules you have to follow at home❓
What are some examples of prejudice❓
What is more important to you, appearance or personality❓
What is most important to you in a friend--loyalty, generosity, honesty--why❓
What is something that makes you melancholy❓
What makes your best friend your best friend❓
What makes you feel safe❓
What makes you laugh❓
What would you invent to make life better❓
What would you do to entertain your family without spending any money❓
What effects does watching violence have on people❓
What effects do cigarette and alcohol advertising have on young people❓
What kind of t.v. commercial would you like to make❓ Describe it.
What kind of pet would you most like to have--monkey, snake, goat--why❓
What kind of program do you enjoy most on TV--detective shows, comedies, game shows--and why❓
What advice would you give a new student❓
What advice would you give to someone who stole something but now feels guilty❓
What things are better than going to school❓ Why❓
What talents do you have❓
What three words would describe you right now❓
What four things are most important in your life❓
What colour makes you think of happiness❓
What has been the most fun activity at school so far❓
What quality do you like about yourself--creativity, personality, appearance--why❓
What eccentric behaviour in a friend disturbs you the most❓
What parts of nature do you like best❓
What do you do for exercise❓
What is the most ludicrous outfit you can think of❓
What is the funniest dinner you've ever had with your family❓
How do you feel when it's your birthday❓ Why❓
How do you feel on the first day of winter❓ Why❓
How would you feel if you were going to be on a show❓ Why❓
How do you feel when you do something wrong❓
How do you feel when you do something that is very good❓
How do you feel when you play a trick on someone❓
How would you feel if a new child moved into your neighbourhood❓
How do you think the new child would feel❓
How do you feel when you have had a fight with your best friend❓
How do you think your friend felt❓
How do you feel when you are in bed with the lights out❓
How do you feel when you want something very badly and you cannot have it❓ Why is this so important to have❓
How do you feel on a warm sunny day❓
How do you feel when you stay with a babysitter❓
How do you feel when you're leaving home on vacation❓
How do you feel when you sleep at someone's house❓
How do you feel during a thunderstorm❓
How do you feel on the first day of school❓
How do you feel when your parents are upset with you❓ Why do they become upset with you❓
How do you feel on Thanksgiving❓ What are you thankful for❓
How do feel on (any holiday)❓
How do you feel when something scares you❓ What do you do when this happens❓
How would you feel if someone told you that you were his or her best friend❓
How do you feel about your appearance❓
How would you change the world to make it better❓
How do you think eating junk food affects you❓
How do you have the most fun--alone, with a large group, with a few friends--and why❓
Explain how to play your favorite game.
How would you describe your house to someone who has never visited there before❓
I wish I had a million... Then I would...
I wish I had one... because
I wish I could be like.... This person is special because....
I wish to be a …………………… when I grow up. Then I will....
I wish there were a law that said..... This would be a good law because....
I wish I could forget the time I ..... because....
I wish trees could..... because....
I wish I could see...... because.....
I wish I could learn..... because.....
I wish I didn't have to eat...... I don't like this food because.....
I wish everyone would learn to ..... Then everyone would.....
I wish I never......
I wish I had one more chance to..... Then I would.....
I wish there was an electric......
I wish I had enough money to......
I wish everyone loved......
I wish all children would......
I wish everyone had.....
I wish I could touch......
I wish animals could...... If they could, then.....
I wish I looked like.... because......
I wish there were no more.....
I wish I didn't have to.....
I wish I could go to.....
I wish there really was..... If there really was, then.....
I wish I could hear......
I wish I could give......
If all my wishes came true, I would......
When you are angry, how do you look❓
When are you happiest❓
When have you felt lonely❓
When do you feel proud❓
When was the last time you cried and why❓
When a friend was in an embarrassing situation, what did you do❓
When it might hurt their feelings, how do you feel about telling your friends the truth❓
When might it be bad to be honest❓
When someone picks on someone else, how do you feel❓ What do you do❓
Once, when you were very frightened, what happened❓
Once, when you were embarrassed, what happened❓
Once, when your feelings were hurt, what happened❓
Describe a time when you felt vengeful.
When you have a problem who do you talk to❓ Why❓
Which quality best describes your life--exciting, organised, dull--and why❓
Which quality do you dislike most about yourself--laziness, selfishness, childishness--and why❓
Which place would you most like to visit--Africa, China, Alaska--why❓
Which holiday has the most meaning for you-Canada Day, Thanksgiving, Valentines Day--and why❓
Which is least important to you--money, power, fame--and why❓
Which is most important to you--being popular, accomplishing things, being organised--and why❓
Which is your favourite Star Wars character (or other movie∕book∕t.v. show, etc.)❓ Why❓
Why is it important to be honest❓
Why is important to have good manners❓
Why do you think adults smoke∕drink❓
Why is exercise important to someone your age❓
Why do you think some people encourage others to smoke∕drink❓
Why do you think the rules you must follow are good or bad❓
Why would it be good to be honest❓
Why have men and women usually only done certain types of work❓
Why should or shouldn't a man stay home to care for the house and children while his wife goes to work❓
Why do you think some people take advantage of others❓
Why do you think prejudice exists in the world❓
Why would we say that someone is 'passing the buck'❓
Why would a Prime Minister have a sign on his desk which read, 'The buck stops here'❓
Why do you think tact is an important quality❓
Why is it not wise to squander your money❓
Explain why we say, 'dead as a door nail'.
Think of your favourite toy. Why do you like it best❓
Think of the best teacher you ever had. Why were they a good teacher❓
Do you think there is too much fighting on t.v. Why or why not❓
Do you think it is necessary to have alcohol at a party in order to have a good time❓
Does it bother you to be around someone who has bad manners❓
Should there be a dress code in places such as school, restaurants, and places of business❓ Why or why not❓
Should animals be used for medical research❓
Should the Canadian Government financially support Olympic teams❓
Should people be prohibited from smoking in certain places❓
Families are important because...
Would you like to be famous❓ Why or why not❓ What would you like to be famous for❓
Who or what has had a strong influence in your life❓
Where would you prefer to be right now--mountains, desert, beach--and why❓
Should you have to do chores around the house❓ Why or why not❓
Should you be required to wear a bike helmet❓ Why or why not❓
Should skateboards be allowed on sidewalks❓
Where do you think we should go on our class fieldtrip this year❓ Why❓
Should you have to take tests in school❓
Should cellphones be allowed in school❓
Can television (or videogames) influence your behaviour❓ How❓
Should schools be year-round❓
Should junk food be banned from schools❓
Should students be required to learn a second language❓