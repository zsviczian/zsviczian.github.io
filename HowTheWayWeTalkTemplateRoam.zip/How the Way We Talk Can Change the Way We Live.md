- {{[[youtube]]: https://youtu.be/dN6li5FfZTc}}
- **The Four Transformational Languages**
    - Your Mental Machine to Counter Your Immunity to Change
    - Based on [How The Way We Talk Can Change The Way We Live](https://www.zsolt.blog/2021/01/how-way-we-talk-can-change-way-we-live.html) post on [Zsolt.blog](https://www.zsolt.blog)
        - {{iframe:https://www.zsolt.blog/2021/01/how-way-we-talk-can-change-way-we-live.html}}
- # Exercise 1
    - **Answer the following question:** What sort of things - if they were to happen more frequently in your work setting - would you experience as being more supportive of your own ongoing development at work? 
        - Alternatively, if you find it easier, you can instead answer a slightly modified version of the question: What sorts of troubling, diminishing, or constraining things — if they were to happen less frequently — would you also find more supportive of your development?
        - Feel free to replace "at work" with whatever context is relevant to you: "at school", "at home", etc.
        - As you answer the question(s) don't edit your responses based on reasonableness, possibility or likelihood. The question is meant to create a thinking exercise.
    - ### Your answers
        -  
        -  
        - 
- # Exercise 2
    - Behind each complaint there is something that you are deeply committed to, but can't realize to the extent you would want to. Take each of your responses to Exercise 1 and complete the following sentence for each: __"I am committed to the importance and value of... "__
    - ### Enter your answers to column 1 of the your Mental Machine below
- # Exercise 3
    - What are you doing, or not doing, that is keeping your commitment from being more fully realized?
    - ### Enter your answers to column 2 of the your Mental Machine below
- # Exercise 4
    - Look at your answers to Exercise 3 and see if you can identify even vaguely like a fear or discomfort associated with doing other than what you have written as an answer (column 2 in the template). Write down this as a possible commitment you might be holding to prevent that thing which you are afraid of from happening in column 3 of the template. __"I may also be committed to..."__
    - ### Enter your answers to column 3 of the your Mental Machine below
- # Exercise 5
    - To uncover your big assumptions you need to compose an assumptive sentence stem using your column 3 commitments. 
        - If in column 3 you have a negative commitment (e.g. __"I'm committed to not being seen as boastful"__), then remove the negative and form a sentence like this: __"I assume that if I were to be seen as a boastful, then ..."__
        - If there is no negative (e.g. __"I may also be committed to pretend that I am invincible"__) then add negative wording like this: __"I assume that if I did not pretend to be invincible, then ..."__
    - Once the assumptive sentence is ready, complete the sentence as quickly and as honestly as you can: **How will I feel, then?**
    - ### Enter your answers to column 4 of the your Mental Machine below
- # Your Mental Machine
    - {{[[table]]}}
        - **Commitment**
I am committed to the 
importance and value of...
            - **What I am doing or not doing 
that prevents my commitment 
from being fully realized**
                - **Competing Commitment**
I might also be committed to ...
                    - **Big Assumptions**
How will I feel then?
        - Commitment 1
            - I may have ...
I may lack ...
I may be ...
                - I might also be committed to ...
I might also be committed to ...
                    - #big-assumption Big Assumption 1
        - Commitment 2
            - I may have ...
I may lack ...
I may be ...
                - I might also be committed to ...
I might also be committed to ...
                    - #big-assumption Big Assumption 2
        - Commitment 3
            - I may have ...
I may lack ...
I may be ...
                - I might also be committed to ...
I might also be committed to ...
                    - #big-assumption Big Assumption 3
- # Creating a Distance Between Yourself and Your Big Assumptions
    - Press the delta button next to each exercise to plant the reminders for these tasks to future Daily Notes pages in your graph. When the day comes reflect on the question and write down your response, then press the delta button again on your daily notes page to push the reminder forward by three days. When you reach the next step, you simply stop promoting the previous step to future days.
    - Each delta function is set up such, that it repeats every third day. When you press the delta buttons on this page today, Step 1 will first appear tomorrow, step 2 in three weeks, step 3 in six weeks, and step 4 in seven weeks.
    - ### Step 1 - duration 3 weeks
        - Observe yourself in relation to your big assumptions. Record your observations. {{[[∆]]:1+3}}
__Do not try to change your big assumptions just yet. The task is simply to notice and keep track of what does or does not occur because of holding your big assumptions true. Record in your diary or share with your partner your observations. In what other areas of your life have you noticed your big assumption driving your actions?__
{{[[query]]: {and: [[table]] [[big-assumption]] {not: [[query]]}}}}
    - ### Step 2 - duration 3 weeks
        - Actively look for experiences that cast doubt on your big assumptions. Record your observations. {{[[∆]]:22+3}}
__Still do not try to change your big assumptions. Lookout for any experiences that cast some doubt on the truthfulness of your big assumptions. Make note of these experiences or share with your partner.__
{{[[query]]: {and: [[table]] [[big-assumption]] {not: [[query]]}}}}
    - ### Step 3 - duration 1 week
        - Explore the history of your big assumptions. Record your observations. {{[[∆]]:43+3}}
__Still do not try to change your big assumptions. Lookout for any experiences that cast some doubt on the truthfulness of your big assumptions. Make note of these experiences or share with your partner.__
{{[[query]]: {and: [[table]] [[big-assumption]] {not: [[query]]}}}}
    - ### Step 4 - duration 4 weeks
        - Design and run a safe test of your big assumptions. Record your observations. {{[[∆]]:50+3}}
__Design a modest safe test of your big assumption. Change perhaps something in your behavior and ask your partner, a friend or colleague to provide you with impressions and feedback when you run your experiment.  Note down your own observations.__
{{[[query]]: {and: [[table]] [[big-assumption]] {not: [[query]]}}}}
